--Új itemek (Container Robbery)

['hardcutter']						= {['name'] = 'hardcutter',					['label'] = 'Hardcutter',					['weight'] = 100, 		['type'] = 'item', 		['image'] = 'hardcutter.png',		['unique'] = true, 		['useable'] = true,		['shouldClose'] = true,		 ['combinable'] = nil, 	 	 	["decay"] = 10.0,     ["created"] = nil,      ['description'] = '...'},
    