fx_version 'bodacious'
game 'gta5'

description 'amir_expert#1911 - LockPick'

version '1.0.0'

client_script 'client/client.lua'

ui_page {
    'html/index.html',
}

files {
    'html/index.html',
    'html/*.css',
    'html/*.js',
}

exports {
    "StartLockPickCircle"
}